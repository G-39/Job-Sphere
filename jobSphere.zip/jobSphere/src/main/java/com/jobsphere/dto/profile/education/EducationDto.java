package com.jobsphere.dto.profile.education;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EducationDto {

    private Long id;
    private String degree;
    private String fieldOfStudy;
    private String institutionName;
    private Integer startYear;
    private Integer endYear;
    private Double percentageOrCgpa;
}
