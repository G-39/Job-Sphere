package com.jobsphere.dto.job;

import lombok.*;
import jakarta.validation.constraints.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CreateJobRequest {

    @NotBlank
    private String title;

    private String description;
    private String location;
    private String salaryRange;

    @NotBlank
    private String category;
}
