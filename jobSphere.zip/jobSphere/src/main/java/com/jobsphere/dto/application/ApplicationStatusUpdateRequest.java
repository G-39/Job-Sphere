package com.jobsphere.dto.application;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApplicationStatusUpdateRequest {
    private String status; // SHORTLISTED, REJECTED, HIRED
}
