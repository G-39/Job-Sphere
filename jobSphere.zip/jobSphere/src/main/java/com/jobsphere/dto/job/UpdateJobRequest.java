package com.jobsphere.dto.job;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UpdateJobRequest {
    private String title;
    private String description;
    private String location;
    private String salaryRange;
    private String category;
}
