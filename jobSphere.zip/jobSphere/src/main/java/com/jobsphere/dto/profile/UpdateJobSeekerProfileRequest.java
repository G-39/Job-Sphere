package com.jobsphere.dto.profile;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UpdateJobSeekerProfileRequest {
    private String fullName;
    private String phone;
    private String location;
    private String skills;
    private Integer experienceYears;
    private String resumeUrl;
}
