package com.jobsphere.dto.job;

import lombok.*;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class JobSearchResponse {
    private List<JobDto> jobs;
    private int page;
    private int size;
    private long totalElements;
    private int totalPages;
}
