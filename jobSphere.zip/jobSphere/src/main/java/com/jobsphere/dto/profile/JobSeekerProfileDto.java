package com.jobsphere.dto.profile;

import com.jobsphere.dto.profile.education.EducationDto;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class JobSeekerProfileDto {

    private Long id;
    private Long userId;

    private String fullName;
    private String phone;
    private String location;
    private String skills;
    private Integer experienceYears;
    private String resumeUrl;

    // ⭐ NEW - List of Education DTOs
    private List<EducationDto> educationList;
}
