package com.jobsphere.dto.application;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class JobApplicationDto {
    private Long id;
    private Long jobId;
    private Long jobSeekerId;
    private String status;
    private String coverLetter;
    private String resumeUrl;
    private String appliedAt;
}
