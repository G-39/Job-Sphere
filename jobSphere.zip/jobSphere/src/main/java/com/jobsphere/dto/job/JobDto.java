package com.jobsphere.dto.job;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class JobDto {
    private Long id;
    private Long recruiterId;
    private String title;
    private String description;
    private String location;
    private String salaryRange;
    private String category;
    private String createdAt;
}
