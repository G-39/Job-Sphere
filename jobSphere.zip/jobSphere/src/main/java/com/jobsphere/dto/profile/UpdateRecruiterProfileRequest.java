package com.jobsphere.dto.profile;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UpdateRecruiterProfileRequest {
    private String companyName;
    private String companyWebsite;
    private String companyDescription;
    private String contactPerson;
}
