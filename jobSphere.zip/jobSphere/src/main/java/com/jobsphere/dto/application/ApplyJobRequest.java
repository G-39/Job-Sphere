package com.jobsphere.dto.application;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApplyJobRequest {
    private String coverLetter;
    private String resumeUrl;
}
