package com.jobsphere.security.jwt;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;

@Component
public class JwtUtil {

    private final Key key;
    private final long expirationMs;

    public JwtUtil(@Value("${jwt.secret:change_me}") String secret,
                   @Value("${jwt.expirationMs:3600000}") long expirationMs) {
        // Ensure secret is at least 32 bytes for HS256 key
        this.key = Keys.hmacShaKeyFor(fitSecret(secret));
        this.expirationMs = expirationMs;
    }

    private byte[] fitSecret(String secret) {
        byte[] b = secret.getBytes();
        if (b.length >= 32) return b;
        byte[] out = new byte[32];
        System.arraycopy(b, 0, out, 0, b.length);
        for (int i = b.length; i < out.length; i++) out[i] = (byte) '0';
        return out;
    }

    public String generateToken(Long userId, String username, String role) {
        Date now = new Date();
        Date exp = new Date(now.getTime() + expirationMs);
        return Jwts.builder()
                .setSubject(String.valueOf(userId))
                .claim("username", username)
                .claim("role", role)
                .setIssuedAt(now)
                .setExpiration(exp)
                .signWith(key, SignatureAlgorithm.HS256)
                .compact();
    }

    public Jws<Claims> validateToken(String token) throws JwtException {
        return Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(token);
    }
}
