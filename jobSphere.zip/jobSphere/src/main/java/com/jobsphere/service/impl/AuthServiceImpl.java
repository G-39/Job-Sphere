package com.jobsphere.service.impl;

import com.jobsphere.dto.user.AuthResponse;
import com.jobsphere.dto.user.LoginRequest;
import com.jobsphere.dto.user.RegisterRequest;
import com.jobsphere.dto.user.UserDto;
import com.jobsphere.entity.user.Role;
import com.jobsphere.entity.user.User;
import com.jobsphere.exception.BadRequestException;
import com.jobsphere.exception.ResourceNotFoundException;
import com.jobsphere.repository.UserRepository;
import com.jobsphere.security.jwt.JwtUtil;
import com.jobsphere.service.auth.AuthService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepository;
    private final ModelMapper modelMapper;
    private final JwtUtil jwtUtil;
    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    @Override
    public AuthResponse register(RegisterRequest request) {
        // basic validation
        if (userRepository.existsByUsername(request.getUsername()))
            throw new BadRequestException("Username already taken");
        if (userRepository.existsByEmail(request.getEmail()))
            throw new BadRequestException("Email already registered");

        Role role;
        try {
            role = Role.valueOf(request.getRole());
        } catch (Exception ex) {
            throw new BadRequestException("Invalid role: " + request.getRole());
        }

        User u = User.builder()
                .username(request.getUsername())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(role)
                .build();

        User saved = userRepository.save(u);
        UserDto dto = modelMapper.map(saved, UserDto.class);
        String token = jwtUtil.generateToken(saved.getId(), saved.getUsername(), saved.getRole().name());
        return AuthResponse.builder().token(token).user(dto).build();
    }

    @Override
    public AuthResponse login(LoginRequest request) {
        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("User not found with username: " + request.getUsername()));
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword()))
            throw new BadRequestException("Invalid credentials");
        UserDto dto = modelMapper.map(user, UserDto.class);
        String token = jwtUtil.generateToken(user.getId(), user.getUsername(), user.getRole().name());
        return AuthResponse.builder().token(token).user(dto).build();
    }

    @Override
    public Long getLoggedInUserId() {
        // placeholder — controllers / security filter should fill principal and call services with explicit userId.
        throw new UnsupportedOperationException("Use controllers to pass current userId (implement extraction from JWT in Security layer)");
    }
}
