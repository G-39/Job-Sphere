package com.jobsphere.service.impl;

import com.jobsphere.dto.job.*;
import com.jobsphere.entity.job.Job;
import com.jobsphere.entity.job.JobCategory;
import com.jobsphere.entity.profile.RecruiterProfile;
import com.jobsphere.exception.AccessDeniedException;
import com.jobsphere.exception.BadRequestException;
import com.jobsphere.exception.ResourceNotFoundException;
import com.jobsphere.repository.JobRepository;
import com.jobsphere.repository.RecruiterProfileRepository;
import com.jobsphere.service.job.JobService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class JobServiceImpl implements JobService {

    private final JobRepository jobRepository;
    private final RecruiterProfileRepository recruiterProfileRepository;
    private final ModelMapper mapper;

    @Override
    public JobDto createJob(Long recruiterUserId, CreateJobRequest request) {
        RecruiterProfile recruiter = recruiterProfileRepository.findByUserId(recruiterUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Recruiter profile not found for userId: " + recruiterUserId));

        JobCategory cat;
        try {
            cat = JobCategory.valueOf(request.getCategory());
        } catch (Exception ex) {
            throw new BadRequestException("Invalid job category: " + request.getCategory());
        }

        Job job = Job.builder()
                .recruiter(recruiter)
                .title(request.getTitle())
                .description(request.getDescription())
                .location(request.getLocation())
                .salaryRange(request.getSalaryRange())
                .category(cat)
                .build();

        Job saved = jobRepository.save(job);
        return mapper.map(saved, JobDto.class);
    }

    @Override
    public JobDto updateJob(Long jobId, Long recruiterUserId, UpdateJobRequest request) {
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new ResourceNotFoundException("Job not found with id: " + jobId));

        // check ownership
        if (!job.getRecruiter().getUser().getId().equals(recruiterUserId))
            throw new AccessDeniedException("You are not the owner of this job");

        if (request.getTitle() != null) job.setTitle(request.getTitle());
        if (request.getDescription() != null) job.setDescription(request.getDescription());
        if (request.getLocation() != null) job.setLocation(request.getLocation());
        if (request.getSalaryRange() != null) job.setSalaryRange(request.getSalaryRange());
        if (request.getCategory() != null) {
            try {
                job.setCategory(JobCategory.valueOf(request.getCategory()));
            } catch (Exception ex) {
                throw new BadRequestException("Invalid job category: " + request.getCategory());
            }
        }

        Job saved = jobRepository.save(job);
        return mapper.map(saved, JobDto.class);
    }

    @Override
    public void deleteJob(Long jobId, Long recruiterUserId) {
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new ResourceNotFoundException("Job not found with id: " + jobId));
        if (!job.getRecruiter().getUser().getId().equals(recruiterUserId))
            throw new AccessDeniedException("You are not the owner of this job");
        jobRepository.delete(job);
    }

    @Override
    public JobDto getJobById(Long jobId) {
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new ResourceNotFoundException("Job not found with id: " + jobId));
        return mapper.map(job, JobDto.class);
    }

    @Override
    public List<JobDto> getJobsByRecruiter(Long recruiterUserId) {
        RecruiterProfile recruiter = recruiterProfileRepository.findByUserId(recruiterUserId)
                .orElseThrow(() -> new ResourceNotFoundException("Recruiter profile not found for userId: " + recruiterUserId));
        return jobRepository.findByRecruiter(recruiter).stream()
                .map(j -> mapper.map(j, JobDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public JobSearchResponse searchJobs(String keyword, String location, String category, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Direction.DESC, "createdAt"));
        Page<Job> resultPage;

        if (category != null && !category.isBlank()) {
            JobCategory cat;
            try {
                cat = JobCategory.valueOf(category);
                resultPage = jobRepository.findAll(Example.of(Job.builder().category(cat).build()), pageable);
            } catch (Exception ex) {
                throw new BadRequestException("Invalid category: " + category);
            }
        } else if (keyword != null && !keyword.isBlank()) {
            // naive search on title/description
            List<Job> list = jobRepository.findByTitleContainingIgnoreCase(keyword);
            int start = (int) pageable.getOffset();
            int end = Math.min((start + pageable.getPageSize()), list.size());
            List<JobDto> dtos = list.subList(start, end).stream().map(j -> mapper.map(j, JobDto.class)).collect(Collectors.toList());
            return JobSearchResponse.builder()
                    .jobs(dtos)
                    .page(page)
                    .size(size)
                    .totalElements(list.size())
                    .totalPages((int) Math.ceil((double) list.size() / size))
                    .build();
        } else if (location != null && !location.isBlank()) {
            List<Job> list = jobRepository.findByLocationContainingIgnoreCase(location);
            int start = (int) pageable.getOffset();
            int end = Math.min((start + pageable.getPageSize()), list.size());
            List<JobDto> dtos = list.subList(start, end).stream().map(j -> mapper.map(j, JobDto.class)).collect(Collectors.toList());
            return JobSearchResponse.builder()
                    .jobs(dtos)
                    .page(page)
                    .size(size)
                    .totalElements(list.size())
                    .totalPages((int) Math.ceil((double) list.size() / size))
                    .build();
        } else {
            resultPage = jobRepository.findAll(pageable);
        }

        List<JobDto> dtos = resultPage.stream().map(j -> mapper.map(j, JobDto.class)).collect(Collectors.toList());
        return JobSearchResponse.builder()
                .jobs(dtos)
                .page(resultPage.getNumber())
                .size(resultPage.getSize())
                .totalElements(resultPage.getTotalElements())
                .totalPages(resultPage.getTotalPages())
                .build();
    }
}
