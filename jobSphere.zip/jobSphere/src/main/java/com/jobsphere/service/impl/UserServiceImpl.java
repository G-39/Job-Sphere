package com.jobsphere.service.impl;

import com.jobsphere.dto.user.UserDto;
import com.jobsphere.entity.user.User;
import com.jobsphere.entity.user.Role;
import com.jobsphere.exception.BadRequestException;
import com.jobsphere.exception.ResourceNotFoundException;
import com.jobsphere.repository.UserRepository;
import com.jobsphere.service.user.UserService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final ModelMapper mapper;

    @Override
    public UserDto getUserById(Long id) {
        User u = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
        return mapper.map(u, UserDto.class);
    }

    @Override
    public List<UserDto> getAllUsers() {
        return userRepository.findAll().stream()
                .map(u -> mapper.map(u, UserDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public void deleteUser(Long id) {
        User u = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
        userRepository.delete(u);
    }

    @Override
    public UserDto updateUserRole(Long userId, String roleStr) {
        User u = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));
        Role role;
        try {
            role = Role.valueOf(roleStr);
        } catch (Exception ex) {
            throw new BadRequestException("Invalid role: " + roleStr);
        }
        u.setRole(role);
        User saved = userRepository.save(u);
        return mapper.map(saved, UserDto.class);
    }
}
