package com.jobsphere.service.impl;

import com.jobsphere.dto.profile.JobSeekerProfileDto;
import com.jobsphere.dto.profile.UpdateJobSeekerProfileRequest;
import com.jobsphere.entity.profile.JobSeekerProfile;
import com.jobsphere.entity.user.User;
import com.jobsphere.exception.ResourceNotFoundException;
import com.jobsphere.repository.JobSeekerProfileRepository;
import com.jobsphere.repository.UserRepository;
import com.jobsphere.service.profile.JobSeekerProfileService;

import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class JobSeekerProfileServiceImpl implements JobSeekerProfileService {

    private final JobSeekerProfileRepository profileRepository;
    private final UserRepository userRepository;
    private final ModelMapper mapper;

    // ----------------------
    // CREATE PROFILE
    // ----------------------
    @Override
    public JobSeekerProfileDto createProfile(Long userId, UpdateJobSeekerProfileRequest request) {

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

        // Check if profile already exists
        if (profileRepository.findByUserId(userId).isPresent()) {
            throw new ResourceNotFoundException("Profile already exists for userId: " + userId);
        }

        JobSeekerProfile profile = JobSeekerProfile.builder()
                .user(user)
                .fullName(request.getFullName())
                .phone(request.getPhone())
                .location(request.getLocation())
                .skills(request.getSkills())
                .experienceYears(request.getExperienceYears())
                .resumeUrl(request.getResumeUrl())
                .build();

        JobSeekerProfile saved = profileRepository.save(profile);
        return mapper.map(saved, JobSeekerProfileDto.class);
    }

    // ----------------------
    // UPDATE PROFILE
    // ----------------------
    @Override
    public JobSeekerProfileDto updateProfile(Long userId, UpdateJobSeekerProfileRequest request) {
        JobSeekerProfile profile = profileRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("JobSeeker profile not found for userId: " + userId));

        if (request.getFullName() != null) profile.setFullName(request.getFullName());
        if (request.getPhone() != null) profile.setPhone(request.getPhone());
        if (request.getLocation() != null) profile.setLocation(request.getLocation());
        if (request.getSkills() != null) profile.setSkills(request.getSkills());
        if (request.getExperienceYears() != null) profile.setExperienceYears(request.getExperienceYears());
        if (request.getResumeUrl() != null) profile.setResumeUrl(request.getResumeUrl());

        JobSeekerProfile saved = profileRepository.save(profile);
        return mapper.map(saved, JobSeekerProfileDto.class);
    }

    // ----------------------
    // GET PROFILE
    // ----------------------
    @Override
    public JobSeekerProfileDto getProfileByUserId(Long userId) {
        JobSeekerProfile profile = profileRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("JobSeeker profile not found for userId: " + userId));

        return mapper.map(profile, JobSeekerProfileDto.class);
    }
}
