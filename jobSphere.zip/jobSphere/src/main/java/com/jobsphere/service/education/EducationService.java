package com.jobsphere.service.education;

import com.jobsphere.dto.profile.education.*;

import java.util.List;

public interface EducationService {

    EducationDto addEducation(Long jobSeekerId, CreateOrUpdateEducationRequest request);

    EducationDto updateEducation(Long id, CreateOrUpdateEducationRequest request);

    void deleteEducation(Long id);

    List<EducationDto> getEducationByJobSeeker(Long jobSeekerId);
}
