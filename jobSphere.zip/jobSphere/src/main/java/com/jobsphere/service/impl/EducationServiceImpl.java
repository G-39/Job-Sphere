package com.jobsphere.service.impl;

import com.jobsphere.dto.profile.education.*;
import com.jobsphere.entity.profile.JobSeekerProfile;
import com.jobsphere.entity.profile.education.Education;
import com.jobsphere.repository.EducationRepository;
import com.jobsphere.repository.JobSeekerProfileRepository;
import com.jobsphere.service.education.EducationService;

import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class EducationServiceImpl implements EducationService {

    private final EducationRepository educationRepository;
    private final JobSeekerProfileRepository jobSeekerProfileRepository;
    private final ModelMapper mapper;

    @Override
    public EducationDto addEducation(Long jobSeekerId, CreateOrUpdateEducationRequest request) {
        JobSeekerProfile seeker = jobSeekerProfileRepository.findById(jobSeekerId)
                .orElseThrow(() -> new RuntimeException("Job Seeker not found"));

        Education education = mapper.map(request, Education.class);
        education.setJobSeekerProfile(seeker);

        return mapper.map(educationRepository.save(education), EducationDto.class);
    }

    @Override
    public EducationDto updateEducation(Long id, CreateOrUpdateEducationRequest request) {
        Education edu = educationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Education record not found"));

        mapper.map(request, edu);

        return mapper.map(educationRepository.save(edu), EducationDto.class);
    }

    @Override
    public void deleteEducation(Long id) {
        educationRepository.deleteById(id);
    }

    @Override
    public List<EducationDto> getEducationByJobSeeker(Long jobSeekerId) {
        return educationRepository.findByJobSeekerProfileId(jobSeekerId)
                .stream()
                .map(e -> mapper.map(e, EducationDto.class))
                .collect(Collectors.toList());
    }
}
