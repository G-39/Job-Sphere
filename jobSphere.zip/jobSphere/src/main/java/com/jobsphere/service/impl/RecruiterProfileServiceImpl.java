package com.jobsphere.service.impl;

import com.jobsphere.dto.profile.RecruiterProfileDto;
import com.jobsphere.dto.profile.UpdateRecruiterProfileRequest;
import com.jobsphere.entity.profile.RecruiterProfile;
import com.jobsphere.entity.user.User;
import com.jobsphere.exception.ResourceNotFoundException;
import com.jobsphere.repository.RecruiterProfileRepository;
import com.jobsphere.repository.UserRepository;
import com.jobsphere.service.profile.RecruiterProfileService;

import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class RecruiterProfileServiceImpl implements RecruiterProfileService {

    private final RecruiterProfileRepository recruiterProfileRepository;
    private final UserRepository userRepository;
    private final ModelMapper mapper;

    // ------------------------
    // CREATE PROFILE
    // ------------------------
    @Override
    public RecruiterProfileDto createProfile(Long userId, UpdateRecruiterProfileRequest request) {

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

        // Check if recruiter profile already exists
        if (recruiterProfileRepository.findByUserId(userId).isPresent()) {
            throw new ResourceNotFoundException("Recruiter profile already exists for userId: " + userId);
        }

        RecruiterProfile profile = RecruiterProfile.builder()
                .user(user)
                .companyName(request.getCompanyName())
                .companyWebsite(request.getCompanyWebsite())
                .companyDescription(request.getCompanyDescription())
                .contactPerson(request.getContactPerson())
                .build();

        RecruiterProfile saved = recruiterProfileRepository.save(profile);
        return mapper.map(saved, RecruiterProfileDto.class);
    }

    // ------------------------
    // UPDATE PROFILE
    // ------------------------
    @Override
    public RecruiterProfileDto updateProfile(Long userId, UpdateRecruiterProfileRequest request) {

        RecruiterProfile profile = recruiterProfileRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Recruiter profile not found for userId: " + userId));

        if (request.getCompanyName() != null) profile.setCompanyName(request.getCompanyName());
        if (request.getCompanyWebsite() != null) profile.setCompanyWebsite(request.getCompanyWebsite());
        if (request.getCompanyDescription() != null) profile.setCompanyDescription(request.getCompanyDescription());
        if (request.getContactPerson() != null) profile.setContactPerson(request.getContactPerson());

        RecruiterProfile saved = recruiterProfileRepository.save(profile);
        return mapper.map(saved, RecruiterProfileDto.class);
    }

    // ------------------------
    // GET PROFILE
    // ------------------------
    @Override
    public RecruiterProfileDto getProfileByUserId(Long userId) {

        RecruiterProfile profile = recruiterProfileRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Recruiter profile not found for userId: " + userId));

        return mapper.map(profile, RecruiterProfileDto.class);
    }
}
