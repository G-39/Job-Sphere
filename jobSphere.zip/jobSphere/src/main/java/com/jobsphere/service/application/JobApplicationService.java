package com.jobsphere.service.application;

import com.jobsphere.dto.application.ApplyJobRequest;
import com.jobsphere.dto.application.ApplicationStatusUpdateRequest;
import com.jobsphere.dto.application.JobApplicationDto;

import java.util.List;

public interface JobApplicationService {

    // -------------------------
    // APPLY FOR A JOB
    // -------------------------
    JobApplicationDto apply(Long jobId, Long jobSeekerId, ApplyJobRequest request);

    // -------------------------
    // UPDATE STATUS OF APPLICATION
    // -------------------------
    JobApplicationDto updateStatus(Long applicationId, ApplicationStatusUpdateRequest request);

    // -------------------------
    // GET ALL APPLICANTS OF A JOB (Recruiter feature)
    // -------------------------
    List<JobApplicationDto> getApplicationsByJob(Long jobId);

    // -------------------------
    // GET ALL APPLICATIONS OF A JOB SEEKER
    // -------------------------
    List<JobApplicationDto> getApplicationsBySeeker(Long jobSeekerId);
}
