package com.jobsphere.service.auth;

import com.jobsphere.dto.user.AuthResponse;
import com.jobsphere.dto.user.LoginRequest;
import com.jobsphere.dto.user.RegisterRequest;
//import com.jobsphere.dto.user.RegisterRequest;
//import com.jobsphere.dto.user.LoginRequest;
public interface AuthService {

    AuthResponse register(RegisterRequest request);

    AuthResponse login(LoginRequest request);

    Long getLoggedInUserId(); // extract from JWT later
}
