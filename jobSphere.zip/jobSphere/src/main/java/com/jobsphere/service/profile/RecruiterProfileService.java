package com.jobsphere.service.profile;

import com.jobsphere.dto.profile.RecruiterProfileDto;
import com.jobsphere.dto.profile.UpdateRecruiterProfileRequest;

public interface RecruiterProfileService {

    RecruiterProfileDto createProfile(Long userId, UpdateRecruiterProfileRequest request);

    RecruiterProfileDto updateProfile(Long userId, UpdateRecruiterProfileRequest request);

    RecruiterProfileDto getProfileByUserId(Long userId);
}
