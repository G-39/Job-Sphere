package com.jobsphere.service.job;

import com.jobsphere.dto.job.CreateJobRequest;
import com.jobsphere.dto.job.JobDto;
import com.jobsphere.dto.job.JobSearchResponse;
import com.jobsphere.dto.job.UpdateJobRequest;

public interface JobService {

    // ------------------------
    // CREATE JOB
    // ------------------------
    JobDto createJob(Long recruiterUserId, CreateJobRequest request);

    // ------------------------
    // UPDATE JOB
    // ------------------------
    JobDto updateJob(Long jobId, Long recruiterUserId, UpdateJobRequest request);

    // ------------------------
    // DELETE JOB
    // ------------------------
    void deleteJob(Long jobId, Long recruiterUserId);

    // ------------------------
    // GET JOB BY ID
    // ------------------------
    JobDto getJobById(Long jobId);

    // ------------------------
    // GET JOBS OF A RECRUITER
    // ------------------------
    java.util.List<JobDto> getJobsByRecruiter(Long recruiterUserId);

    // ------------------------
    // SEARCH JOBS WITH FILTER + PAGINATION
    // ------------------------
    JobSearchResponse searchJobs(
            String keyword,
            String location,
            String category,
            int page,
            int size
    );
}
