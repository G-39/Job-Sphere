package com.jobsphere.service.admin;

import com.jobsphere.dto.user.UserDto;
import com.jobsphere.dto.job.JobDto;

import java.util.List;

public interface AdminService {

    List<UserDto> getAllUsers();

    List<JobDto> getAllJobs();

    void deleteUser(Long userId);

    void deleteJob(Long jobId);
}
