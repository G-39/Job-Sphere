package com.jobsphere.service.profile;

import com.jobsphere.dto.profile.JobSeekerProfileDto;
import com.jobsphere.dto.profile.UpdateJobSeekerProfileRequest;

public interface JobSeekerProfileService {

    JobSeekerProfileDto createProfile(Long userId, UpdateJobSeekerProfileRequest request);

    JobSeekerProfileDto updateProfile(Long userId, UpdateJobSeekerProfileRequest request);

    JobSeekerProfileDto getProfileByUserId(Long userId);
}
