package com.jobsphere.service.user;

import com.jobsphere.dto.user.UserDto;

import java.util.List;

public interface UserService {

    UserDto getUserById(Long id);

    List<UserDto> getAllUsers();

    void deleteUser(Long id);

    UserDto updateUserRole(Long userId, String role);
}
