package com.jobsphere.service.impl;

import com.jobsphere.dto.application.ApplyJobRequest;
import com.jobsphere.dto.application.ApplicationStatusUpdateRequest;
import com.jobsphere.dto.application.JobApplicationDto;
import com.jobsphere.entity.application.ApplicationStatus;
import com.jobsphere.entity.application.JobApplication;
import com.jobsphere.entity.job.Job;
import com.jobsphere.entity.profile.JobSeekerProfile;
import com.jobsphere.exception.BadRequestException;
import com.jobsphere.exception.ResourceNotFoundException;
import com.jobsphere.repository.JobApplicationRepository;
import com.jobsphere.repository.JobRepository;
import com.jobsphere.repository.JobSeekerProfileRepository;
import com.jobsphere.service.application.JobApplicationService;

import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class JobApplicationServiceImpl implements JobApplicationService {

    private final JobApplicationRepository applicationRepository;
    private final JobRepository jobRepository;
    private final JobSeekerProfileRepository jobSeekerProfileRepository;
    private final ModelMapper mapper;

    // ---------------------------------------------------------------
    // APPLY FOR A JOB
    // ---------------------------------------------------------------
    @Override
    public JobApplicationDto apply(Long jobId, Long jobSeekerId, ApplyJobRequest request) {

        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new ResourceNotFoundException("Job not found with id: " + jobId));

        JobSeekerProfile seeker = jobSeekerProfileRepository.findByUserId(jobSeekerId)
                .orElseThrow(() -> new ResourceNotFoundException("JobSeeker profile not found for userId: " + jobSeekerId));

        // Prevent duplicate application
        if (applicationRepository.findByJobAndJobSeeker(job, seeker).isPresent()) {
            throw new BadRequestException("You have already applied for this job");
        }

        JobApplication app = JobApplication.builder()
                .job(job)
                .jobSeeker(seeker)
                .coverLetter(request.getCoverLetter())
                .resumeUrl(
                        request.getResumeUrl() != null
                                ? request.getResumeUrl()
                                : seeker.getResumeUrl()
                )
                .status(ApplicationStatus.APPLIED)
                .build();

        JobApplication saved = applicationRepository.save(app);

        return mapper.map(saved, JobApplicationDto.class);
    }

    // ---------------------------------------------------------------
    // GET ALL APPLICATIONS OF A JOB SEEKER
    // ---------------------------------------------------------------
    @Override
    public List<JobApplicationDto> getApplicationsBySeeker(Long jobSeekerId) {

        JobSeekerProfile seeker = jobSeekerProfileRepository.findByUserId(jobSeekerId)
                .orElseThrow(() -> new ResourceNotFoundException("JobSeeker profile not found for userId: " + jobSeekerId));

        return applicationRepository.findByJobSeeker(seeker).stream()
                .map(a -> mapper.map(a, JobApplicationDto.class))
                .collect(Collectors.toList());
    }

    // ---------------------------------------------------------------
    // GET ALL APPLICATIONS FOR A JOB (Recruiter feature)
    // ---------------------------------------------------------------
    @Override
    public List<JobApplicationDto> getApplicationsByJob(Long jobId) {

        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new ResourceNotFoundException("Job not found with id: " + jobId));

        return applicationRepository.findByJob(job).stream()
                .map(a -> mapper.map(a, JobApplicationDto.class))
                .collect(Collectors.toList());
    }

    // ---------------------------------------------------------------
    // UPDATE APPLICATION STATUS
    // ---------------------------------------------------------------
    @Override
    public JobApplicationDto updateStatus(Long applicationId, ApplicationStatusUpdateRequest request) {

        JobApplication app = applicationRepository.findById(applicationId)
                .orElseThrow(() ->
                        new ResourceNotFoundException("Application not found with id: " + applicationId));

        try {
            app.setStatus(ApplicationStatus.valueOf(request.getStatus()));
        } catch (Exception ex) {
            throw new BadRequestException("Invalid status: " + request.getStatus());
        }

        JobApplication saved = applicationRepository.save(app);

        return mapper.map(saved, JobApplicationDto.class);
    }
}
