package com.jobsphere.service.impl;

import com.jobsphere.dto.job.JobDto;
import com.jobsphere.dto.user.UserDto;
import com.jobsphere.entity.job.Job;
import com.jobsphere.entity.user.User;
import com.jobsphere.exception.ResourceNotFoundException;
import com.jobsphere.repository.JobRepository;
import com.jobsphere.repository.UserRepository;
import com.jobsphere.service.admin.AdminService;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AdminServiceImpl implements AdminService {

    private final UserRepository userRepository;
    private final JobRepository jobRepository;
    private final ModelMapper mapper;

    @Override
    public List<UserDto> getAllUsers() {
        return userRepository.findAll().stream().map(u -> mapper.map(u, UserDto.class)).collect(Collectors.toList());
    }

    @Override
    public List<JobDto> getAllJobs() {
        return jobRepository.findAll().stream().map(j -> mapper.map(j, JobDto.class)).collect(Collectors.toList());
    }

    @Override
    public void deleteUser(Long userId) {
        User u = userRepository.findById(userId).orElseThrow(() -> new ResourceNotFoundException("User not found"));
        userRepository.delete(u);
    }

    @Override
    public void deleteJob(Long jobId) {
        Job j = jobRepository.findById(jobId).orElseThrow(() -> new ResourceNotFoundException("Job not found"));
        jobRepository.delete(j);
    }
}
