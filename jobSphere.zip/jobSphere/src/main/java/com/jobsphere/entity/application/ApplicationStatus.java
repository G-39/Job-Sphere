package com.jobsphere.entity.application;

public enum ApplicationStatus {
    APPLIED,
    SHORTLISTED,
    REJECTED,
    HIRED
}
