package com.jobsphere.entity.job;

public enum JobCategory {
    IT,
    HR,
    SALES,
    MARKETING,
    FINANCE,
    OTHER
}
