package com.jobsphere.entity.user;

public enum Role {
    JOB_SEEKER,
    RECRUITER,
    ADMIN
}
