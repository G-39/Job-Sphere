package com.jobsphere.entity.profile;

import com.jobsphere.entity.profile.education.Education;
import com.jobsphere.entity.user.User;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "job_seeker_profile")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class JobSeekerProfile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // One-to-one with User table
    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id", nullable = false, unique = true)
    @ToString.Exclude
    private User user;

    @Column(name = "full_name", length = 200)
    private String fullName;

    @Column(length = 50)
    private String phone;

    @Column(length = 200)
    private String location;

    @Column(columnDefinition = "TEXT")
    private String skills; // CSV or simple text

    @Column(name = "experience_years")
    private Integer experienceYears;

    @Column(name = "resume_url", length = 500)
    private String resumeUrl;

    // ⭐ NEW: One JobSeeker has many Education records
    @OneToMany(mappedBy = "jobSeekerProfile", cascade = CascadeType.ALL, orphanRemoval = true)
    @ToString.Exclude
    private List<Education> educationList = new ArrayList<>();

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
