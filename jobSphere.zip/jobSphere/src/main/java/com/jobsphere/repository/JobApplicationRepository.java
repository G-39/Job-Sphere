package com.jobsphere.repository;

import com.jobsphere.entity.application.JobApplication;
import com.jobsphere.entity.job.Job;
import com.jobsphere.entity.profile.JobSeekerProfile;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface JobApplicationRepository extends JpaRepository<JobApplication, Long> {

    Optional<JobApplication> findByJobAndJobSeeker(Job job, JobSeekerProfile seeker);

    List<JobApplication> findByJob(Job job);

    List<JobApplication> findByJobSeeker(JobSeekerProfile seeker);
}
