package com.jobsphere.repository;

import com.jobsphere.entity.profile.RecruiterProfile;
import com.jobsphere.entity.user.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RecruiterProfileRepository extends JpaRepository<RecruiterProfile, Long> {

    Optional<RecruiterProfile> findByUser(User user);

    Optional<RecruiterProfile> findByUserId(Long userId);
}
