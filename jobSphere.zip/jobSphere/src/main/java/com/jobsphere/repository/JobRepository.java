package com.jobsphere.repository;

import com.jobsphere.entity.job.Job;
import com.jobsphere.entity.job.JobCategory;
import com.jobsphere.entity.profile.RecruiterProfile;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface JobRepository extends JpaRepository<Job, Long> {

    List<Job> findByCategory(JobCategory category);

    List<Job> findByLocationContainingIgnoreCase(String location);

    List<Job> findByTitleContainingIgnoreCase(String title);

    List<Job> findByRecruiter(RecruiterProfile recruiterProfile);
}
