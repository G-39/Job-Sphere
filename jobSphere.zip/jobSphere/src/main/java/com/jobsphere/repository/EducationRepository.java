package com.jobsphere.repository;

import com.jobsphere.entity.profile.education.Education;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EducationRepository extends JpaRepository<Education, Long> {

    List<Education> findByJobSeekerProfileId(Long jobSeekerId);
}
