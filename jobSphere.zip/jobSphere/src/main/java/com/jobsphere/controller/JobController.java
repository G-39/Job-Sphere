package com.jobsphere.controller;

import com.jobsphere.dto.job.CreateJobRequest;
import com.jobsphere.dto.job.JobDto;
import com.jobsphere.dto.job.JobSearchResponse;
import com.jobsphere.dto.job.UpdateJobRequest;
import com.jobsphere.service.job.JobService;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/jobs")
@RequiredArgsConstructor
public class JobController {

    private final JobService jobService;

    // ---------------------------------------------------------
    // CREATE JOB (Recruiter)
    // ---------------------------------------------------------
    @PostMapping("/create/{recruiterId}")
    public JobDto createJob(
            @PathVariable Long recruiterId,
            @RequestBody CreateJobRequest request) {
        return jobService.createJob(recruiterId, request);
    }

    // ---------------------------------------------------------
    // UPDATE JOB (Recruiter)
    // ---------------------------------------------------------
    @PutMapping("/update/{jobId}/{recruiterId}")
    public JobDto updateJob(
            @PathVariable Long jobId,
            @PathVariable Long recruiterId,
            @RequestBody UpdateJobRequest request) {
        return jobService.updateJob(jobId, recruiterId, request);
    }

    // ---------------------------------------------------------
    // DELETE JOB (Recruiter)
    // ---------------------------------------------------------
    @DeleteMapping("/delete/{jobId}/{recruiterId}")
    public String deleteJob(
            @PathVariable Long jobId,
            @PathVariable Long recruiterId) {

        jobService.deleteJob(jobId, recruiterId);
        return "Job deleted successfully.";
    }

    // ---------------------------------------------------------
    // GET JOB BY ID
    // ---------------------------------------------------------
    @GetMapping("/{jobId}")
    public JobDto getJobById(@PathVariable Long jobId) {
        return jobService.getJobById(jobId);
    }

    // ---------------------------------------------------------
    // GET ALL JOBS POSTED BY A RECRUITER
    // ---------------------------------------------------------
    @GetMapping("/recruiter/{recruiterId}")
    public List<JobDto> getJobsByRecruiter(@PathVariable Long recruiterId) {
        return jobService.getJobsByRecruiter(recruiterId);
    }

    // ---------------------------------------------------------
    // SEARCH JOBS WITH FILTERS + PAGINATION
    // ---------------------------------------------------------
    @GetMapping("/search")
    public JobSearchResponse searchJobs(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String location,
            @RequestParam(required = false) String category,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        return jobService.searchJobs(keyword, location, category, page, size);
    }
}
