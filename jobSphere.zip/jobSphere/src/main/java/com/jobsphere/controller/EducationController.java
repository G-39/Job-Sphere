package com.jobsphere.controller;

import com.jobsphere.dto.profile.education.CreateOrUpdateEducationRequest;
import com.jobsphere.dto.profile.education.EducationDto;
import com.jobsphere.service.education.EducationService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/education")
@RequiredArgsConstructor
public class EducationController {

    private final EducationService educationService;

    @PostMapping("/{jobSeekerId}")
    public EducationDto addEducation(
            @PathVariable Long jobSeekerId,
            @RequestBody CreateOrUpdateEducationRequest request) {
        return educationService.addEducation(jobSeekerId, request);
    }

    @PutMapping("/{id}")
    public EducationDto updateEducation(
            @PathVariable Long id,
            @RequestBody CreateOrUpdateEducationRequest request) {
        return educationService.updateEducation(id, request);
    }

    @DeleteMapping("/{id}")
    public String deleteEducation(@PathVariable Long id) {
        educationService.deleteEducation(id);
        return "Education deleted successfully.";
    }

    @GetMapping("/jobseeker/{jobSeekerId}")
    public List<EducationDto> getEducation(@PathVariable Long jobSeekerId) {
        return educationService.getEducationByJobSeeker(jobSeekerId);
    }
}
