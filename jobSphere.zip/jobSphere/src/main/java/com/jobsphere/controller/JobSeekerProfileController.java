package com.jobsphere.controller;

import com.jobsphere.dto.profile.JobSeekerProfileDto;
import com.jobsphere.dto.profile.UpdateJobSeekerProfileRequest;
import com.jobsphere.service.profile.JobSeekerProfileService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/jobseeker")
@RequiredArgsConstructor
public class JobSeekerProfileController {

    private final JobSeekerProfileService jobSeekerProfileService;

    @PostMapping("/create/{userId}")
    public JobSeekerProfileDto createProfile(
            @PathVariable Long userId,
            @RequestBody UpdateJobSeekerProfileRequest request) {
        return jobSeekerProfileService.createProfile(userId, request);
    }

    @PutMapping("/update/{userId}")
    public JobSeekerProfileDto updateProfile(
            @PathVariable Long userId,
            @RequestBody UpdateJobSeekerProfileRequest request) {
        return jobSeekerProfileService.updateProfile(userId, request);
    }

    @GetMapping("/{userId}")
    public JobSeekerProfileDto getProfile(@PathVariable Long userId) {
        return jobSeekerProfileService.getProfileByUserId(userId);
    }
}
