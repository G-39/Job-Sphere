package com.jobsphere.controller;

import com.jobsphere.dto.application.ApplyJobRequest;
import com.jobsphere.dto.application.ApplicationStatusUpdateRequest;
import com.jobsphere.dto.application.JobApplicationDto;
import com.jobsphere.service.application.JobApplicationService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/applications")
@RequiredArgsConstructor
public class JobApplicationController {

    private final JobApplicationService jobApplicationService;

    @PostMapping("/apply/{jobId}/{jobSeekerId}")
    public JobApplicationDto applyJob(
            @PathVariable Long jobId,
            @PathVariable Long jobSeekerId,
            @RequestBody ApplyJobRequest request) {
        return jobApplicationService.apply(jobId, jobSeekerId, request);
    }

    @PutMapping("/status/{applicationId}")
    public JobApplicationDto updateStatus(
            @PathVariable Long applicationId,
            @RequestBody ApplicationStatusUpdateRequest request) {
        return jobApplicationService.updateStatus(applicationId, request);
    }

    @GetMapping("/job/{jobId}")
    public List<JobApplicationDto> getApplicationsByJob(@PathVariable Long jobId) {
        return jobApplicationService.getApplicationsByJob(jobId);
    }

    @GetMapping("/seeker/{jobSeekerId}")
    public List<JobApplicationDto> getApplicationsBySeeker(@PathVariable Long jobSeekerId) {
        return jobApplicationService.getApplicationsBySeeker(jobSeekerId);
    }
}
