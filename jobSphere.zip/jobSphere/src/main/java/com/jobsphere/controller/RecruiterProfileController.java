package com.jobsphere.controller;

import com.jobsphere.dto.profile.RecruiterProfileDto;
import com.jobsphere.dto.profile.UpdateRecruiterProfileRequest;
import com.jobsphere.service.profile.RecruiterProfileService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/recruiter")
@RequiredArgsConstructor
public class RecruiterProfileController {

    private final RecruiterProfileService recruiterProfileService;

    @PostMapping("/create/{userId}")
    public RecruiterProfileDto createProfile(
            @PathVariable Long userId,
            @RequestBody UpdateRecruiterProfileRequest request) {
        return recruiterProfileService.createProfile(userId, request);
    }

    @PutMapping("/update/{userId}")
    public RecruiterProfileDto updateProfile(
            @PathVariable Long userId,
            @RequestBody UpdateRecruiterProfileRequest request) {
        return recruiterProfileService.updateProfile(userId, request);
    }

    @GetMapping("/{userId}")
    public RecruiterProfileDto getProfile(@PathVariable Long userId) {
        return recruiterProfileService.getProfileByUserId(userId);
    }
}
